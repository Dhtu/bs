create
    definer = root@localhost procedure pro_initData()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i<=900 DO
        INSERT INTO tableData 
        (qid,uid,value) 
        VALUES
        (i%30+1,i/30+1,concat('value',i));
        SET i = i+1;
    END WHILE;
END;

