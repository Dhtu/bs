create
    definer = root@localhost procedure proc_initData()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i<=30 DO
        INSERT INTO user 
        (uid,uname,upasswoed,email) 
        VALUES
        (i,concat('user',i),'123456',concat(concat('email',i),'@zju.com'));
        SET i = i+1;
    END WHILE;
END;

